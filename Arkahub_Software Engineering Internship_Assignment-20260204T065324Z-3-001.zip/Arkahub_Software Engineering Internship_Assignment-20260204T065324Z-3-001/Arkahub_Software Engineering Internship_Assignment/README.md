# EnergyGrid Data Aggregator

## Overview
This client fetches telemetry data for 500 solar inverters from the EnergyGrid Mock API while respecting strict rate limits and security constraints.

## How It Works
- Devices are batched in groups of 10
- A queue-based rate limiter ensures only 1 request per second
- Each request is signed using MD5(URL + Token + Timestamp)
- Automatic retries handle HTTP 429 responses

## Setup

1. Start the mock API:
   ```bash
   cd mock-api
   npm install
   npm start
