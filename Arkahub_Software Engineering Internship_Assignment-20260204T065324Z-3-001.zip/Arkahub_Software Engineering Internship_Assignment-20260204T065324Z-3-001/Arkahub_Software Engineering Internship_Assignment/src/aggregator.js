const RateLimiter = require("./utils/rateLimiter");
const { postBatch } = require("./api/energyGridClient");

const limiter = new RateLimiter(1000); // 1 req/sec

function generateSerialNumbers(count) {
  return Array.from({ length: count }, (_, i) =>
    `SN-${i.toString().padStart(3, "0")}`
  );
}

function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

async function aggregateData() {
  const serials = generateSerialNumbers(500);
  const batches = chunkArray(serials, 10);

  const results = [];

  for (const batch of batches) {
    const data = await limiter.enqueue(() => postBatch(batch));
    results.push(...data);
    console.log(`✅ Fetched batch (${batch.length})`);
  }

  return results;
}

module.exports = { aggregateData };
