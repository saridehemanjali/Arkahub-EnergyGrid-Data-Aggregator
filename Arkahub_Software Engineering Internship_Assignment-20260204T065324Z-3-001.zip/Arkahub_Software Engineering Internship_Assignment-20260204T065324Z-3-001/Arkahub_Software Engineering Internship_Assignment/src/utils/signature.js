const crypto = require("crypto");

const TOKEN = "interview_token_123";

function generateSignature(url, timestamp) {
  return crypto
    .createHash("md5")
    .update(url + TOKEN + timestamp)
    .digest("hex");
}

module.exports = { generateSignature };
