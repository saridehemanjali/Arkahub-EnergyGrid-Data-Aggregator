const http = require("http");
const { generateSignature } = require("../utils/signature");

const BASE_URL = "http://localhost:3000";
const ENDPOINT = "/device/real/query";

function postBatch(snList, retryCount = 3) {
  return new Promise((resolve, reject) => {
    const timestamp = Date.now().toString();
    const signature = generateSignature(ENDPOINT, timestamp);

    const body = JSON.stringify({ sn_list: snList });

    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body),
        timestamp,
        signature
      }
    };

    const req = http.request(BASE_URL + ENDPOINT, options, (res) => {
      let data = "";

      res.on("data", chunk => (data += chunk));
      res.on("end", () => {
        if (res.statusCode === 200) {
          resolve(JSON.parse(data).data);
        } else if (res.statusCode === 429 && retryCount > 0) {
          console.log("⚠️ 429 received, retrying...");
          setTimeout(
            () => postBatch(snList, retryCount - 1).then(resolve).catch(reject),
            1000
          );
        } else {
          reject(new Error(`Request failed: ${res.statusCode}`));
        }
      });
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

module.exports = { postBatch };
