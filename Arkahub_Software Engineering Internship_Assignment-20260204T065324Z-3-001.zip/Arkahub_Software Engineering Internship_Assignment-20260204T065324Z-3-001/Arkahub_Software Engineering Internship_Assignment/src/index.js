const { aggregateData } = require("./aggregator");

(async () => {
  try {
    console.log("🔌 Starting EnergyGrid Data Aggregation...");
    const data = await aggregateData();
    console.log(`🎉 Completed! Total devices: ${data.length}`);
    console.log("Sample output:", data.slice(0, 3));
  } catch (err) {
    console.error("❌ Error:", err.message);
  }
})();
